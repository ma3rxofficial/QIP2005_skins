====================================================================
=                                                                  =
=  KOLOBOK For QiP. Original [Big Pack]                            =
=  Author: Aiwan                                                   =
=  QIP - www.qip.ru                                                =
=  Author: Ilham Z (ilham@qip.ru)                                  =
=                                                                  =
====================================================================
=                                                                  =
=                         CONTENTS:                                =
=   - DESCRIPTION                                                  =
=   - PROGRAMS                                                     =
=   - ADDITIONAL NOTES                                             =
=   - LICENSE                                                      =
=                                                                  =
====================================================================

--------------------------------------------------------------------
                           DESCRIPTION
--------------------------------------------------------------------

 Pack of smileys for use with QiP. In pack two variant, for light background.

--------------------------------------------------------------------
                           PROGRAMS
--------------------------------------------------------------------

The following programs were used to create these smiles: 

* Adobe Photoshop 8.0 � for patterns and drawings.
* IrfanView 3.93 � for reviewing and processing of drawings
* Ulead GIF Animator 5.05 � in this program I do everything (and I draw using it) 
* GIF Movie Gear 4.0 � for size reduction and cleaning of GIF final version.  

--------------------------------------------------------------------
                      ADDITIONAL NOTES
--------------------------------------------------------------------

  I don't sell their own smiles and don't get the money for their use. But if you want to contribute, that can send me your donation on WebMoney purse http://www.webmoney.ru:

* RUR - R772310074488 
* EUR - E694924432900 
* USD - Z967960974490 

--------------------------------------------------------------------
                              LICENSE
--------------------------------------------------------------------

- You can distribute them for free use in forums, chats and other applications, as long as the smiles are unmodified and this text file is included within the RAR file. 
- They must not be used commercially without agreeing on the terms with me first.
- You may not repackage them and redistribute them with other smiles without my permission.
- They must not be converted to any other format and distributed without my permission.
- You may not sell them or use them for profit either individually, or in any sort of collection or smiles-pack.
- If you do not agree with this licence, you must remove the files from your storage devices and stop using the archive.
 
  If you have any questions, please email me at Aiwan@yandex.ru.
 
  Truly yours, Aiwan. 
  http://www.kolobok.wrg.ru - Welcome!

DO NOT SEARCH for MY SMILES WHERE THEIR MUST NOT BE!